<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Usertests extends Model
{
    protected $table = "users_tests";
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [

        'id','user_id','doc_path','created_at','updated_at'
    ];
    
    public function getCreatedAtAttribute($value)
    {
        return $this->attributes['created_at'] = date('d-M-Y h:i A', strtotime($value));
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Profiles;
use App\Services;
use App\Usertests;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
    
    public function users() {
        $users = User::all();
        return view('users', compact('users'));
    }
    
    public function profiles() {
        $profiles = Profiles::all();
        return view('profiles', compact('profiles'));
    }
    
    public function services() {
        $services = Services::all();
        return view('services', compact('services'));
    }
    
    public function usertests() {
        $usertests = Usertests::all();
        return view('usertests', compact('usertests'));
    }
    
    public function editservices($id) {
        $services = Services::where('id', $id)->first();
        return view('serviceedit', compact('services'));
    }
    
    public function editprofiles($id) {
        $profiles = Profiles::where('id', $id)->first();
        return view('profileedit', compact('profiles'));
    }
    
    public function addservices() {
      return view('serviceadd');
    }
    
    public function addprofiles() {
      return view('profileadd');
    }
    
    public function deleteservices($id) {
        $services_delete = Services::where('id', $id)->first();
        if(isset($services_delete) && isset($services_delete->file))
        {
        $file = $services_delete->file;
        $file_path = public_path().'/uploads/'.$file;
        unlink($file_path);
        $services_delete->delete();
        }

        $services = Services::all();
        return view('services', compact('services'));
    }
    
    public function deleteprofiles($id) {
        $profiles_delete = Profiles::where('id', $id)->first();
        if(isset($profiles_delete) && isset($profiles_delete->file))
        {
        $file = $profiles_delete->file;
        $file_path = public_path().'/uploads/'.$file;
        unlink($file_path);
        $profiles_delete->delete();
        }

        $profiles = Profiles::all();
        return view('profiles', compact('profiles'));
    }
    
    public function saveservices(Request $request) {
        
        if(isset($request['id']))
        {
        $services_cr = Services::where('id', $request['id'])->first();
        }
        
        if((isset($services_cr) && !isset($services_cr->file)) || $request->file('file') !== NULL)
        {
        $this->validate($request, ['file' => 'required|mimes:jpeg,png,jpg,gif|max:100040',]);
        }
        
        
        if(!isset($services_cr))
        {
        $services_cr = New Services;
        }
        
        //print_r($request->all());
        //exit;

        $this->validate($request, [
            'investigation' => 'required',
            'mrp' => 'required|numeric',
            'sample' => 'required',
            'reporting' => 'required',
        ]);

        $name = '';
        if ($request->hasFile('file')) {
            $image = $request->file('file');
            $name = time() . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('/uploads');
            $image->move($destinationPath, $name);
            $services_cr->file = $name;
        }
        
         $services_cr->investigations = $request['investigation'];
         $services_cr->mrp = $request['mrp'];
         $services_cr->sample_type_and_volume = $request['sample'];
         $services_cr->reporting = $request['reporting'];
         $services_cr->save();

        $services = Services::all();
        return view('services', compact('services'));
    }
    
    public function saveprofiles(Request $request) {
        
        if(isset($request['id']))
        {
        $profiles_cr = Profiles::where('id', $request['id'])->first();
        }
        
        if((isset($profiles_cr) && !isset($profiles_cr->file)) || $request->file('file') !== NULL)
        {
        $this->validate($request, ['file' => 'required|mimes:jpeg,png,jpg,gif|max:100040',]);
        }
        
        
        if(!isset($profiles_cr))
        {
        $profiles_cr = New Profiles;
        }
        
        //print_r($request->all());
        //exit;

        $this->validate($request, [
            'investigation' => 'required',
            'mrp' => 'required|numeric',
            'sample' => 'required',
            'reporting' => 'required',
        ]);

        $name = '';
        if ($request->hasFile('file')) {
            $image = $request->file('file');
            $name = time() . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('/uploads');
            $image->move($destinationPath, $name);
            $profiles_cr->file = $name;
        }
        
         $profiles_cr->investigations = $request['investigation'];
         $profiles_cr->mrp = $request['mrp'];
         $profiles_cr->sample_type_and_volume = $request['sample'];
         $profiles_cr->reporting = $request['reporting'];
         $profiles_cr->save();

        $profiles = Profiles::all();
        return view('profiles', compact('profiles'));
    }
    
    public function createpackages() {
    $profiles = Profiles::all();
    $services = Services::all();
    return view('createpackages', compact('profiles', 'services'));
    }
}

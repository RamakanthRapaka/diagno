<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use App\Http\Requests;
use JWTAuth;
use Response;
use App\Repository\Transformers\UserTransformer;
use App\Repository\Transformers\UsertestsTransformer;
use \Illuminate\Http\Response as Res;
use Validator;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Log;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenBlacklistedException;
use Illuminate\Database\QueryException as QueryException;
use App\Http\Controllers\MailController;
use Image;
use File;
use Storage;
use App\Usertests;

class UserController extends ApiController {

    /**
     * @var \App\Repository\Transformers\UserTransformer
     * */
    protected $userTransformer;
    protected $UsertestsTransformer;
    protected $MailController;

    public function __construct(userTransformer $userTransformer, UsertestsTransformer $UsertestsTransformer, MailController $MailController) {

        $this->userTransformer = $userTransformer;
        $this->UsertestsTransformer = $UsertestsTransformer;
        $this->MailController = $MailController;
    }

    public function CheckAuth($api_token) {

        $user = NULL;
        try {
            $user = JWTAuth::toUser($api_token);
        } catch (QueryException $e) {
            Log::emergency($e);
            return $this->respondInternalErrors();
        } catch (\PDOException $e) {
            Log::emergency($e);
            return $this->respondInternalErrors();
        } catch (Exception $e) {
            Log::emergency($e);
        } catch (TokenInvalidException $e) {
            $this->clearUserToken($user);
            return $this->respondTokenExpired();
        } catch (TokenBlacklistedException $e) {
            $this->clearUserToken($user);
            return $this->respondTokenExpired();
        } catch (TokenExpiredException $e) {
            $this->clearUserToken($user);
            return $this->respondTokenExpired();
        } catch (JWTException $e) {
            $this->clearUserToken($user);
            return $this->respondTokenExpired();
        }

        if (!isset($user) || empty($user) || $user == null) {
            return $this->respondTokenExpired();
        }
    }

    /**
     * @description: Api user authenticate method
     * @author: Adelekan David Aderemi
     * @param: email, password
     * @return: Json String response
     */
    /*public function authenticate(Request $request) {

        $rules = array(
            'mobile' => 'required|regex:/^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/',
            'password' => 'required',
        );

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {

            return $this->respondValidationError('Fields Validation Failed.', $validator->errors());
        } else {

            $user = User::where('mobile', $request['mobile'])->first();

            if ($user) {
                $api_token = $user->api_token;

                if ($api_token == NULL) {
                    return $this->_login($request['mobile'], $request['password'], 'login');
                }

                try {

                    $user = JWTAuth::toUser($api_token);

                    return $this->respond([

                                'status' => 'success',
                                'status_code' => $this->getStatusCode(),
                                'message' => 'Already logged in',
                                'user' => $this->userTransformer->transform($user)
                    ]);
                } catch (JWTException $e) {

                    $user->api_token = NULL;
                    $user->save();

                    return $this->respondInternalError("Login Unsuccessful: " . $e);
                }
            } else {
                return $this->respondWithError("Invalid Email or Password");
            }
        }
    }*/
    
    
    public function authenticate(Request $request) {

        $rules = array(
            'mobile' => 'required|regex:/^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/',
            'password' => 'required',
        );

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {

            return $this->respondValidationError('Fields Validation Failed.', $validator->errors());
        }

        $user = '';
        $credentials = ['mobile' => $request['mobile'], 'password' => $request['password'], 'role' => 2];

        try {
            $user_mobile = User::where('mobile', $request['mobile'])->where('role', 2)->first();
        } catch (QueryException $e) {
            Log::emergency($e);
            return $this->respondInternalErrors();
        } catch (\PDOException $e) {
            Log::emergency($e);
            return $this->respondInternalErrors();
        }

        try {
            if (auth()->validate($credentials)) {
                $user = User::where('mobile', $request['mobile'])->first();
            }
        } catch (QueryException $e) {
            Log::emergency($e);
            return $this->respondInternalErrors();
        } catch (\PDOException $e) {
            Log::emergency($e);
            return $this->respondInternalErrors();
        }


        if ($user) {
            $api_token = $user->api_token;

            if ($api_token == NULL) {
                return $this->_login($request['mobile'], $request['mobile'], 'login');
            }

            try {

                try {
                    $user = JWTAuth::toUser($api_token);
                } catch (QueryException $e) {
                    Log::emergency($e);
                    return $this->respondInternalErrors();
                } catch (\PDOException $e) {
                    Log::emergency($e);
                    return $this->respondInternalErrors();
                }

                return $this->respond([
                            'status' => 'success',
                            'status_code' => $this->getStatusCode(),
                            'message' => 'Already logged in',
                            'data' => $this->userTransformer->transform($user),
                ]);
            } catch (TokenInvalidException $e) {
                Log::emergency($e);
                return $this->respondWithsessionError();
            } catch (TokenBlacklistedException $e) {
                Log::emergency($e);
                $user->api_token = NULL;
                $user->save();
                return $this->respondWithsessionError();
            } catch (TokenExpiredException $e) {
                return $this->_login($request['mobile'], $request['mobile'], 'login');
            } catch (JWTException $e) {
                Log::emergency($e);
                $user->api_token = NULL;
                $user->save();
                return $this->respondWithsessionError();
            }
        } else if (isset($user_mobile)) {
            return $this->respondWithError("Invalid Password");
        } else if (!isset($user_mobile)) {
            return $this->respondWithError("Invalid Mobile");
        } else {
            return $this->respondWithError("Invalid Mobile or Password");
        }
    }

    private function _login($mobile, $password, $where) {

        $credentials = ['mobile' => $mobile, 'password' => $password, 'role' => 2];


        if (!$token = JWTAuth::attempt($credentials)) {

            return $this->respondWithError("User does not exist!");
        }

        $user = JWTAuth::toUser($token);

        $user->api_token = $token;
        $user->save();

        /*if ($where == 'register') {
            $this->sendotp($user->api_token);
        }*/

        return $this->respond([

                    'status' => 'success',
                    'status_code' => $this->getStatusCode(),
                    'message' => 'Login successful!',
                    'data' => $this->userTransformer->transform($user)
        ]);
    }

    /**
     * @description: Api user register method
     * @author: Adelekan David Aderemi
     * @param: lastname, firstname, username, email, password
     * @return: Json String response
     */
    public function register(Request $request) {

        $rules = array(
            'name' => 'sometimes|nullable|max:255',
            'email' => 'sometimes|nullable|email|max:255',
            'mobile' => 'required|regex:/^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/',
            'dob' => 'sometimes|nullable|date|date_format:Y-m-d',
            'gender' => array('sometimes|nullable', 'regex:/^male$|^female$|^others$|^MALE$|^FEMALE$|^OTHERS$/'),
            'blood_group' => array('sometimes|nullable', 'regex:/^(A|B|AB|O)[+-]$/'),
            'password' => 'sometimes|nullable|min:6',
            'otp' => 'sometimes|nullable|numeric|digits:5',
        );

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {

            return $this->respondValidationError('Fields Validation Failed.', $validator->errors());
        } 
        
        $user_exists = User::where('mobile', $request['mobile'])->first();
        
        if(!$validator->fails() && isset($user_exists) && $request['otp'] === NULL)
        {
        
            if (isset($user_exists)) {
                $random_number = $this->big_rand(5);
                $user_exists->otp = $random_number;
                $user_exists->otp_validity = date('Y-m-d H:i:s');
                $user_exists->save();

                $this->sendotpmail($user_exists, $random_number);

                $user_exists->subject = 'Thank you for Signup!';
                $this->MailController->login($user_exists);
            }
            
            return $this->respond([
                        'status' => 'success',
                        'status_code' => Res::HTTP_OK,
                        'message' => 'OTP Sent Successfully To Your Mobile and Email!',
            ]);
            
        }
        
        if (!$validator->fails() && !isset($user_exists) && $request['otp'] === NULL) {
            $user = User::create([
                        'name' => $request['name'],
                        'email' => $request['email'],
                        'password' => \Hash::make($request['mobile']),
                        'mobile' => $request['mobile'],
                        'dob' => $request['dob'],
                        'gender' => $request['gender'],
                        'blood_group' => $request['blood_group'],
                        'role' => 2
            ]);

            if ($user) {
                $random_number = $this->big_rand(5);
                $user->otp = $random_number;
                $user->otp_validity = date('Y-m-d H:i:s');
                $user->save();

                $this->sendotpmail($user, $random_number);

                $user->subject = 'Thank you for Signup!';
                $this->MailController->login($user);
            }
            
            return $this->respond([
                        'status' => 'success',
                        'status_code' => Res::HTTP_CREATED,
                        'message' => 'You Registered And OTP Sent Successfully To Your Mobile and Email!',
            ]);
            //return $this->_login($request['mobile'], $request['mobile'], 'register');
        }
        
        if(!$validator->fails() && isset($user_exists) && $request['otp'] !== NULL)
        {
            
        $user_valid = User::where('otp', $request['otp'])->where('id', $user_exists->id)->where('mobile', $request['mobile'])->first();  
        
        if(isset($user_valid))
        {
        $user_valid->mobile_verified = 1;
        $user_valid->otp = NULL;
        $user_valid->save();
        
        return $this->_login($request['mobile'], $request['mobile'], 'register');
        
        }
        else {
            
            return $this->respond([
                        'status' => 'error',
                        'status_code' => Res::HTTP_UNAUTHORIZED,
                        'message' => 'Please Check Your Mobile Number Or OTP!',
            ]);
            
        }
        
        }
    }

    /**
     * @description: Api user logout method
     * @author: Adelekan David Aderemi
     * @param: null
     * @return: Json String response
     */
    public function logout($api_token) {

        try {

            $user = JWTAuth::toUser($api_token);

            $user->api_token = NULL;

            $user->save();

            JWTAuth::setToken($api_token)->invalidate();

            $this->setStatusCode(Res::HTTP_OK);

            return $this->respond([

                        'status' => 'success',
                        'status_code' => $this->getStatusCode(),
                        'message' => 'Logout successful!',
            ]);
        } catch (JWTException $e) {

            return $this->respondInternalError("An error occurred while performing an action!");
        }
    }

    public function big_rand($len = 9) {
        $rand = '';
        while (!( isset($rand[$len - 1]) )) {
            $rand .= mt_rand();
        }
        return substr($rand, 0, $len);
    }
    
    public function sendotpmail($user, $random_number) {
        
        $isError = 0;
        $errorMessage = true;

        $postData = '{"Account":{"User":"calllabs","Password":"calllabs","SenderId":"TESTIN","Channel":"1","DCS":"0","SchedTime":null,"GroupId":null},"Messages":[{"Number":"91' . $user->mobile . '","Text":"Your OTP for Registration is ' . $random_number . '"}]}';
        $url = "smspackage.wiaratechnologies.com/RestAPI/MT.svc/mt";
        $headers = array('Content-Type: application/json');

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);


        //Ignore SSL certificate verification
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);


        //get response
        $output = curl_exec($ch);

        //Print error if any
        if (curl_errno($ch)) {
            $isError = true;
            $errorMessage = curl_error($ch);
        }
        curl_close($ch);


        if ($isError) {
            return $this->respond([
                        'status' => 'Error',
                        'status_code' => Res::HTTP_INTERNAL_SERVER_ERROR,
                        'message' => $errorMessage,
            ]);
        } else {
            Log::info($postData);
            $xml = simplexml_load_string($output);
            $json = json_encode($xml);
            $array = json_decode($json, TRUE);

            if (isset($array) && isset($array['ErrorCode']) && $array['ErrorCode'] == 000) {
                $status_code = Res::HTTP_OK;
            }

            if (isset($array) && isset($array['ErrorCode']) && $array['ErrorCode'] != 000) {
                $status_code = Res::HTTP_INTERNAL_SERVER_ERROR;
            }

            return $this->respond([
                        'status' => 'success',
                        'status_code' => $status_code,
                        'message' => $array['ErrorMessage'],
                        'data' => ''
            ]);
        }
    }
    
    public function sendotp(Request $request) {
        
        
        $rules = array(
            'api_token' => 'required',
            'otp' => 'required|numeric|digits:5',
            'mobile' => 'required|regex:/^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/'
        );

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {

            return $this->respondValidationError('Fields Validation Failed.', $validator->errors());
        }

        $process = $this->CheckAuth($request['api_token']);
        if (isset($process)) {
            return $process;
        }
        $user = JWTAuth::toUser($request['api_token']);
        
        if(isset($request['otp']))
        {
        $user_valid = User::where('otp', $request['otp'])->where('id', $user->id)->where('mobile', $request['mobile'])->first();  
        if(isset($user_valid))
        {
        $user->mobile_verified = 1;
        $user->otp = NULL;
        $user->save();
        
        return $this->respond([
                        'status' => 'success',
                        'status_code' => Res::HTTP_OK,
                        'message' => 'Mobile Verified Successfully !',
        ]);
        }
        else {
        
        return $this->respond([
                        'status' => 'error',
                        'status_code' => Res::HTTP_BAD_REQUEST,
                        'message' => 'Invalid OTP CODE!',
        ]);
            
        }
        
        }
        
        if(!isset($request['otp']) && $request['otp'] == NULL)
        {
        $random_number = $this->big_rand(5);
        $user->otp = $random_number;
        $user->otp_validity = date('Y-m-d H:i:s');
        $user->save();

        $isError = 0;
        $errorMessage = true;

        $postData = '{"Account":{"User":"calllabs","Password":"calllabs","SenderId":"TESTIN","Channel":"1","DCS":"0","SchedTime":null,"GroupId":null},"Messages":[{"Number":"91' . $user->mobile . '","Text":"Your OTP for Registration is ' . $random_number . '"}]}';
        $url = "smspackage.wiaratechnologies.com/RestAPI/MT.svc/mt";
        $headers = array('Content-Type: application/json');

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);


        //Ignore SSL certificate verification
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);


        //get response
        $output = curl_exec($ch);

        //Print error if any
        if (curl_errno($ch)) {
            $isError = true;
            $errorMessage = curl_error($ch);
        }
        curl_close($ch);


        if ($isError) {
            return $this->respond([
                        'status' => 'Error',
                        'status_code' => Res::HTTP_INTERNAL_SERVER_ERROR,
                        'message' => $errorMessage,
            ]);
        } else {
            Log::info($postData);
            $xml = simplexml_load_string($output);
            $json = json_encode($xml);
            $array = json_decode($json, TRUE);

            if (isset($array) && isset($array['ErrorCode']) && $array['ErrorCode'] == 000) {
                $status_code = Res::HTTP_OK;
            }

            if (isset($array) && isset($array['ErrorCode']) && $array['ErrorCode'] != 000) {
                $status_code = Res::HTTP_INTERNAL_SERVER_ERROR;
            }

            return $this->respond([
                        'status' => 'success',
                        'status_code' => $status_code,
                        'message' => $array['ErrorMessage'],
                        'data' => ''
            ]);
        }
        }
    }

    public function clearUserToken($user) {

        if (!empty($user)) {
            $user->api_token = NULL;

            try {
                $user->save();
            } catch (QueryException $e) {
                Log::emergency($e);
                return $this->queryError();
            } catch (\PDOException $e) {
                Log::emergency($e);
                return $this->queryError();
            }
        }
    }
    
    public function uploadDoc(Request $request) {

        $rules = array(
            'api_token' => 'required',
            'document' => 'required|image|mimes:jpeg,png,jpg|max:2048'
        );

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {

            return $this->respondValidationError('Fields Validation Failed.', $validator->errors());
        }

        $process = $this->CheckAuth($request['api_token']);

        if (isset($process)) {
            return $process;
        }

        $user = JWTAuth::toUser($request['api_token']);

        $path_folder = public_path() . '/uploads/' . $user->id;
        if (!File::exists($path_folder)) {

            try {
                $result = File::makeDirectory($path_folder, 0777);
            } catch (\Exception $e) {
                Log::emergency($e);
                return $this->respondInternalErrors();
            }
        }

        $file = $request->file('document')->getClientOriginalName();
        $filename = pathinfo($file, PATHINFO_FILENAME);

        $name = str_replace(' ', '_', $filename);
        
        $extension = $request['document']->getClientOriginalExtension();
        
        $png_url = $name . time() . ".".$extension."";
        $path = $path_folder . '/' . $png_url;
        
        try {
            $request->file('document')->move($path_folder . '/', $png_url);
        } catch (\Exception $e) {
            Log::emergency($e);
            return $this->respondInternalErrors();
        }
        
        $user_tests = Usertests::create([
                    'user_id' => $user->id,
                    'doc_path' => "uploads/" . $user->id . '/' . $png_url,
        ]);
        
        return $this->respond([
                    'status' => 'success',
                    'status_code' => Res::HTTP_CREATED,
                    'message' => 'Document Uploaded Successfull!',
                    'data' => $this->UsertestsTransformer->transform($user_tests)
        ]);
    }

}
